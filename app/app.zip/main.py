#!/usr/bin/env python3
import os, re, sys, ssl, json, base64, traceback, urllib.request, urllib.parse
from urllib.parse import unquote_plus
from http.server import HTTPServer, BaseHTTPRequestHandler
from socketserver import ThreadingMixIn
from concurrent.futures import ThreadPoolExecutor, wait

base_dir = os.path.dirname(os.path.realpath(__file__))
data_dir = os.path.join(base_dir, "python_data")
os.makedirs(os.path.join(data_dir, "resources"), exist_ok=True)
os.environ["LIBRESOLVEURL_CONFIG_DIR"] = data_dir
os.environ["LIBRESOLVEURL_ADDON_PATH"] = data_dir

for p in (base_dir, data_dir, os.path.join(base_dir, "LibResolveURL")):
    if p not in sys.path:
        sys.path.insert(0, p)

try:
    ssl._create_default_https_context = ssl._create_unverified_context
except Exception:
    pass

UA = "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36"

LIBRESOLVEURL_AVAILABLE = False
libresolveurl = None
try:
    import libresolveurl
    try:
        import xbmcaddon
        xbmcaddon._xml_defaults = None
    except Exception:
        pass
    try:
        import resolveurl.common as common
        common.settings_file = os.path.join(data_dir, "resources", "settings.xml")
        common.RAND_UA = UA
        common.FF_USER_AGENT = UA
        common.CHROME_USER_AGENT = UA
        from resolveurl.lib import net
        orig_init = net.Net.__init__
        def patched_net_init(self, *args, **kwargs):
            kwargs["ssl_verify"] = False
            orig_init(self, *args, **kwargs)
        net.Net.__init__ = patched_net_init
        from resolveurl.hmf import HostedMediaFile
        HostedMediaFile._HostedMediaFile__test_stream = lambda self, s: (True, "")
    except Exception as e:
        print(f"DEBUG: Net/common patch warning: {e}")
    LIBRESOLVEURL_AVAILABLE = True
except Exception as e:
    print(f"DEBUG: libresolveurl import error: {e}")

def host_name(url: str) -> str:
    m = re.search(r"://(?:www\.)?([^/]+)", url)
    return m.group(1).split(".")[0].upper() if m else "WIDEO"

def clean_and_unwrap_url(url: str) -> str:
    url = (url or "").strip()
    if url.startswith("{"):
        try:
            obj = json.loads(url)
            url = str(obj.get("src") or obj.get("url") or url).strip()
        except Exception:
            pass
    if url.startswith("//"):
        url = "https:" + url
    is_supp = False
    if LIBRESOLVEURL_AVAILABLE and libresolveurl:
        try:
            is_supp = libresolveurl.is_supported(url)
        except Exception:
            is_supp = False
    if "tmp-url" in url or not is_supp:
        try:
            req = urllib.request.Request(url, headers={"User-Agent": UA, "Referer": "https://filman.cc/"})
            with urllib.request.urlopen(req, timeout=5) as resp:
                final_u = resp.geturl()
                body = resp.read().decode("utf-8", errors="ignore")
            me = re.search(r'var\s+_e\s*=\s*[\'"]([A-Za-z0-9+/=]+)[\'"]', body)
            ma = re.search(r'var\s+_a\s*=\s*[\'"]([^\'"]+)[\'"]', body)
            mb = re.search(r'var\s+_b\s*=\s*[\'"]([^\'"]+)[\'"]', body)
            mc = re.search(r'var\s+_c\s*=\s*[\'"]([^\'"]+)[\'"]', body)
            if me and ma and mb and mc:
                raw = base64.b64decode(me.group(1))
                key = (ma.group(1) + mb.group(1) + mc.group(1)).encode("utf-8")
                dec = bytes([raw[i] ^ key[i % len(key)] for i in range(len(raw))]).decode("utf-8", errors="ignore").strip()
                if dec.startswith("http"):
                    return dec
            if final_u and final_u != url and final_u.startswith("http"):
                return final_u
            m_ifr = re.search(r'<iframe[^>]+src=[\'"](https?://[^\'"]+)[\'"]', body, re.I)
            if m_ifr:
                return m_ifr.group(1).strip()
        except Exception:
            pass
    return url

def fallback_regex_resolve(url: str):
    try:
        req = urllib.request.Request(url, headers={"User-Agent": UA, "Referer": "https://filman.cc/"})
        with urllib.request.urlopen(req, timeout=6) as resp:
            html = resp.read().decode("utf-8", errors="ignore")
        redir = re.search(r'window\.location\.href\s*=\s*[\'"](https?://[^\'"]+)[\'"]', html)
        if redir:
            url = redir.group(1)
            if LIBRESOLVEURL_AVAILABLE and libresolveurl:
                try:
                    r_red = libresolveurl.resolve(url)
                    if r_red:
                        return r_red
                except Exception:
                    pass
            req2 = urllib.request.Request(url, headers={"User-Agent": UA, "Referer": "https://filman.cc/"})
            with urllib.request.urlopen(req2, timeout=6) as resp2:
                html = resp2.read().decode("utf-8", errors="ignore")
        if "Byse Frontend" in html or "video-embed-mode" in html:
            try:
                from resolveurl.plugins.byse import ByseResolver
                m_byse = re.search(r"://([^/]+)/(?:e|d)/([0-9a-zA-Z]+)", url)
                if m_byse:
                    return ByseResolver().get_media_url(m_byse.group(1), m_byse.group(2))
            except Exception:
                pass
        r_voe = re.search(r'json">\["([^"]+)"]</script>\s*<script\s*src="([^"]+)', html)
        if r_voe:
            try:
                from resolveurl.plugins.voesx import VoeResolver
                u2 = urllib.parse.urljoin(url, r_voe.group(2))
                req_v = urllib.request.Request(u2, headers={"User-Agent": UA, "Referer": url})
                with urllib.request.urlopen(req_v, timeout=5) as rv:
                    html2 = rv.read().decode("utf-8", errors="ignore")
                repl = re.search(r"(\[(?:'\W{2}'[,\]]){1,9})", html2)
                if repl:
                    s = VoeResolver.voe_decode(r_voe.group(1), repl.group(1))
                    for k in ("source", "file", "direct_access_url"):
                        if s.get(k):
                            return str(s.get(k)) + f"|User-Agent={UA}&Referer={url}"
            except Exception:
                pass
        try:
            from resolveurl.lib import jsunpack
            for packed in re.findall(r"(eval\(function\(p,a,c,k,e,[dr]\).*?\)\))", html, re.S):
                unpacked = jsunpack.unpack(packed)
                m_u = re.search(r'[\'"](https?://[^\'"]+\.(?:m3u8|mp4)[^\'"]*)[\'"]', unpacked)
                if m_u:
                    return m_u.group(1) + f"|User-Agent={UA}&Referer={url}"
        except Exception:
            pass
        m_mp4 = re.search(r'sourcesCode\s*:\s*\[\s*\{\s*src:\s*[\'"](https?://[^\'"]+)[\'"]', html) or re.search(r'<source[^>]+src=[\'"](https?://[^\'"]+\.mp4[^\'"]*)[\'"]', html)
        if m_mp4:
            return m_mp4.group(1) + f"|User-Agent={UA}&Referer={url}"
        m_rob = re.search(r'id=[\'"]robotlink[\'"][^>]*>([^<]+)', html)
        m_tok = re.search(r'getElementById\([\'"]robotlink[\'"]\)\.innerHTML\s*\+\s*[\'"]([^\'"]+)[\'"]', html)
        if m_rob and m_tok:
            return "https:" + m_rob.group(1).strip() + m_tok.group(1).strip() + f"|User-Agent={UA}&Referer={url}"
        m_hls = re.search(r'[\'"]hls[\'"]\s*:\s*[\'"](https?://[^\'"]+\.m3u8[^\'"]*)[\'"]', html) or re.search(r'(https?://[^\s\'"<>\\]+\.m3u8[^\s\'"<>\\]*)', html)
        if m_hls:
            return m_hls.group(1) + f"|User-Agent={UA}&Referer={url}"
        for b64 in re.findall(r'[\'"](aHR0c[A-Za-z0-9+/=]{16,})[\'"]', html):
            try:
                d = base64.b64decode(b64).decode("utf-8", errors="ignore")
                if d.startswith("http") and (".m3u8" in d or ".mp4" in d):
                    return d + f"|User-Agent={UA}&Referer={url}"
            except Exception:
                pass
    except Exception:
        pass
    return None

def resolve_single_item(item):
    try:
        if isinstance(item, str):
            raw_url, language, quality, extra_headers = item, "PL", "HD", {}
        elif isinstance(item, dict):
            raw_url = item.get("url") or ""
            language = item.get("language") or item.get("lang") or "PL"
            quality = item.get("quality") or "HD"
            extra_headers = item.get("headers") or {}
        else:
            return None, None
        url = clean_and_unwrap_url(raw_url)
        if not url or "upzone.cc" in url or "ekino.link" in url or "ekino.ws/watch" in url:
            return None, None
        headers = {"User-Agent": UA, "Referer": url}
        if isinstance(extra_headers, dict):
            headers.update(extra_headers)
        resolved = None
        if LIBRESOLVEURL_AVAILABLE and libresolveurl:
            try:
                resolved = libresolveurl.resolve(url)
            except Exception:
                resolved = None
        if not resolved:
            resolved = fallback_regex_resolve(url)
        if resolved:
            if "|" in resolved:
                resolved_url, header_str = resolved.split("|", 1)
                for pair in header_str.split("&"):
                    if "=" in pair:
                        k, v = pair.split("=", 1)
                        headers[k.strip()] = unquote_plus(v.strip())
                resolved = resolved_url.strip()
            headers.pop("verifypeer", None)
            return ({"host": host_name(url), "url": resolved, "headers": headers, "language": language, "quality": quality}, None)
        else:
            return (None, {"host": host_name(url) + " (Web)", "url": url, "headers": {"User-Agent": UA, "Referer": "https://filman.cc/"}, "language": language, "quality": quality})
    except Exception:
        return None, None

class ThreadingHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True

class ResolverHandler(BaseHTTPRequestHandler):
    def _send_json(self, status: int, payload):
        body = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)
    def do_GET(self):
        self._send_json(200, {"status": "ok", "libresolveurl": LIBRESOLVEURL_AVAILABLE})
    def do_POST(self):
        if not self.path.startswith("/resolve"):
            self._send_json(404, {"error": "Not found"})
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
            raw_body = self.rfile.read(length).decode("utf-8", errors="ignore")
            data = json.loads(raw_body) if raw_body else []
            links = data if isinstance(data, list) else data.get("links", [])
            results, fallbacks = [], []
            if links:
                ex = ThreadPoolExecutor(max_workers=8)
                futures = [ex.submit(resolve_single_item, item) for item in links[:14]]
                done, not_done = wait(futures, timeout=14.0)
                for fut in done:
                    try:
                        res, fb = fut.result()
                        if res:
                            results.append(res)
                        elif fb:
                            fallbacks.append(fb)
                    except Exception:
                        pass
                for fut in not_done:
                    fut.cancel()
                ex.shutdown(wait=False)
            final_out = results if len(results) > 0 else fallbacks
            self._send_json(200, final_out)
        except Exception as e:
            self._send_json(500, {"error": str(e)})

if __name__ == "__main__":
    port = int(os.environ.get("RESOLVER_PORT", "8080"))
    print(f"ResolveURL server starting on http://0.0.0.0:{port}")
    sys.stdout.flush()
    ThreadingHTTPServer(("0.0.0.0", port), ResolverHandler).serve_forever()
